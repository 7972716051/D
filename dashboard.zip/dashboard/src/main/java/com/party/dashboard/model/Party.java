package com.party.dashboard.model;

import java.util.Random;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.MongoId;

import lombok.Data;


@Data
@Document(collection="party")
public class Party {
    @MongoId
    String id;
    String firstName;
    String lastName;
    String dateOfBirth;
    Address address;
    ContactChannel contactChannel;
    String genderIdentity;
    private String partyId;
    private String occupation;
	public String getId() {
		return id;
	}
	public void generatePartyId() {
        if (this.partyId == null) {
            Random random = new Random();
            int randomId = random.nextInt();
            this.partyId = String.valueOf(randomId);
            
        }
	}
	
	public void setId(String id) {
		this.id = id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public ContactChannel getContactChannel() {
		return contactChannel;
	}
	public void setContactChannel(ContactChannel contactChannel) {
		this.contactChannel = contactChannel;
	}
	public String getGenderIdentity() {
		return genderIdentity;
	}
	public void setGenderIdentity(String genderIdentity) {
		this.genderIdentity = genderIdentity;
	}
	public String getPartyId() {
		return partyId;
	}
	public void setPartyId(String partyId) {
		this.partyId = partyId;
	}
	public String getOccupation() {
		return occupation;
	}
	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}
	public String getdob() {
		// TODO Auto-generated method stub
		return null;
	}
	public void setdob(String getdob) {
		// TODO Auto-generated method stub
		
	}
    
  
}
