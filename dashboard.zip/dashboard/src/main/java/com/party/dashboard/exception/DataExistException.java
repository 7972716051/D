package com.party.dashboard.exception;

public class DataExistException extends RuntimeException {

    public DataExistException(String message) {
        super(message);
    }
}
